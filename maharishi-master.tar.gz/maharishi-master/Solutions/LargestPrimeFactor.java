public class LargestPrimeFactor {

  public static int largestPrimeFactor(int n){
      if (n <= 1) return 0;

      int number = n;
      while (number >1){
          if (n % number == 0) {
              boolean isPrime = true;
              for (int i=2; i<number; i++){
                  if (number % i == 0){
                      isPrime = false;
                      break;
                  }
              }
              if (isPrime) return number;
          }
          number--;
      }
      return 0;
  }

  public static void main(String[] args){  
      System.out.println(largestPrimeFactor(10));
      System.out.println(largestPrimeFactor(6936));
      System.out.println(largestPrimeFactor(1));
  }
}
