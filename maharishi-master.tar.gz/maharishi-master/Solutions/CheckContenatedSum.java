public class CheckContenatedSum{

    static int checkContenatedSum(int n, int catlen){
        int originalNumber = n;
        int totalSum = 0;
        while (n!=0){
            int digit = n%10;
            int concatSum = 0;
            for(int i=0; i<catlen; i++){
                concatSum = (concatSum * 10) + digit;
            }
            totalSum += concatSum;
            n = n/10;
        }
        return (originalNumber==totalSum?1:0);
    }

    public static void main(String[] args){
        System.out.println(checkContenatedSum(198,2));
        System.out.println(checkContenatedSum(198,3));
        System.out.println(checkContenatedSum(2997,3));
        System.out.println(checkContenatedSum(2997,2));
        System.out.println(checkContenatedSum(13332,4));
        System.out.println(checkContenatedSum(9,1));
    }
}
