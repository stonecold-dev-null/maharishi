/**
 * Depth
 */
public class Depth {

    public static void main(String[] args) {
        int n = 42;

        System.out.println(depth(n));
    }

    static int depth(int n) {
        int a[] = new int[10];

        for (int i = 1; i < Integer.MAX_VALUE; i++) {
            int pro = 0;

            pro = n * i;
            
            cont = pro % 10;

            for (int j = 0; j < a.length; j++) {
                
            }

        }
    }
}