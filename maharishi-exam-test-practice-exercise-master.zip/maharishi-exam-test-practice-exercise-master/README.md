# maharishi-exam-test-practice-exercise

This is an excerse collection while preparing for maharishi entry exam
